class ShortenedUrl < ApplicationRecord
    validates :short_url, :long_url, :user_id, presence: true
    validates :short_url, uniqueness: true
    def self.code
        SecureRandom::urlsafe_base64(long_url.length)
    end
end
