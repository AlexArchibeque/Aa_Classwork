
#   create_table "courses", force: :cascade do |t|
#     t.string "name"
#     t.integer "prereq_id"
#     t.integer "instructor_id"
#     t.datetime "created_at", null: false
#     t.datetime "updated_at", null: false
#   end
class Course < ApplicationRecord

    # belongs_to :instructor,
    #     primary_key: :id,
    #     foreign_key: :instructor_id,
    #     class_name: :User

    belongs_to(:instructor, {primary_key: :id, :foreign_key => :instructor_id, class_name: 'User'})

    has_many :enrollments,
        primary_key: :id,
        foreign_key: :course_id,
        class_name: :Enrollment

    belongs_to :pre_requisite,
        primary_key: :id,
        foreign_key: :prereq_id,
        class_name: :Course

    has_one :higher_level_course,
        primary_key: :id,
        foreign_key: :prereq_id,
        class_name: :Course

    has_many :students,
        through: :enrollments,
        source: :student

end
